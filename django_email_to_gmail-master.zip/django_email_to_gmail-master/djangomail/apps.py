from django.apps import AppConfig


class DjangomailConfig(AppConfig):
    name = 'djangomail'
